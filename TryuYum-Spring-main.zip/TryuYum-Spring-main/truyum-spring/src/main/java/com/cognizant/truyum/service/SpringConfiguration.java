package com.cognizant.truyum.service;

import org.springframework.context.annotation.Configuration;

import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource("spring-config.xml")
public class SpringConfiguration {

}
